<html>
<head>
<title>测试例子</title>
<meta content="text/html" charset="utf-8" >
</head>
<body>
<ul>
<li>
<a href="getcontent.php">获取网页内容实例</a>
<a href="graphic.php">图像处理实例</a>
<a href="database.php">数据库封装函数实例</a>
<a href="mailtest.php">mail实例</a>
</li>
</ul>



</body>
</html>
